"""Gera embeddings E5 e publica uma coleção Chroma persistente versionada."""
import sys
from unb_gama_rag.config import carregar_config, configurar_cache
from unb_gama_rag.indexacao import indexar


def main():
    config = carregar_config()
    configurar_cache(config)
    try:
        manifesto = indexar(config)
    except (ValueError, OSError) as erro:
        print(f'Não foi possível indexar: {erro}', file=sys.stderr)
        return 1
    print(f"Fontes aprovadas: {manifesto['corpus']['aprovadas_no_catalogo']}")
    print(f"Fontes indexadas: {manifesto['corpus']['total_fontes']}")
    print(f"Chunks/vetores: {manifesto['indice']['total']} × {manifesto['embeddings']['dimensao']}")
    print(f"Coleção ativa: {manifesto['indice']['colecao']} (cosine)")
    print(f"Vetores: {manifesto['vetores']['origem_nesta_execucao']}")
    print(f"Manifesto: {config['caminhos']['manifesto']}")
    for fonte in manifesto['corpus']['fora_do_indice']:
        print(f"Fora do índice: {fonte['source_id']} — {fonte['motivo']}")
    return 0


if __name__ == '__main__':
    sys.exit(main())
