"""Generate local, versioned E5 embeddings for the prepared pilot. No vector DB."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
import platform
import time
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
# Keep SDK caches inside this project; never send a cached account token.
os.environ["HF_HOME"] = str(ROOT / ".cache/huggingface")
os.environ["HF_HUB_DISABLE_IMPLICIT_TOKEN"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

MODEL_FILES = [
    "model.safetensors", "config.json", "modules.json", "sentence_bert_config.json",
    "tokenizer.json", "tokenizer_config.json", "special_tokens_map.json", "1_Pooling/config.json",
]


def sha_file(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(block)
    return hasher.hexdigest()


def text_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def load_model(config: dict, allow_download: bool):
    from huggingface_hub import snapshot_download
    from sentence_transformers import SentenceTransformer
    import torch

    settings = config["embeddings"]
    destination = ROOT / settings["local_model_directory"]
    if allow_download:
        print("Downloading only the pinned model files; corpus data stays local.", flush=True)
        snapshot_download(
            repo_id=settings["model"], revision=settings["revision"],
            local_dir=destination, cache_dir=ROOT / ".cache/huggingface/hub",
            allow_patterns=MODEL_FILES, token=False, max_workers=2,
        )
    missing = [name for name in MODEL_FILES if not (destination / name).is_file()]
    if missing:
        raise ValueError(f"Model files missing: {missing}. Run once with --download-model.")
    hashes = {name: sha_file(destination / name) for name in MODEL_FILES}
    if hashes["model.safetensors"] != settings["weights_sha256"]:
        raise ValueError("Model weights do not match the pinned SHA-256")
    if hashes["tokenizer.json"] != config["chunking"]["tokenizer_sha256"]:
        raise ValueError("Model tokenizer differs from the tokenizer used to prepare chunks")
    modules = json.loads((destination / "modules.json").read_text(encoding="utf-8"))
    allowed = {"sentence_transformers.models.Transformer", "sentence_transformers.models.Pooling",
               "sentence_transformers.models.Normalize"}
    if any(module["type"] not in allowed for module in modules):
        raise ValueError("Unexpected model module; inspect before loading")
    pooling = json.loads((destination / "1_Pooling/config.json").read_text(encoding="utf-8"))
    if not pooling.get("pooling_mode_mean_tokens") or pooling.get("pooling_mode_cls_token") or pooling.get("pooling_mode_max_tokens"):
        raise ValueError("Unexpected pooling configuration")
    torch.set_num_threads(settings["cpu_threads"])
    model = SentenceTransformer(
        str(destination), device=settings["initial_device"], local_files_only=True,
        trust_remote_code=False, token=False, cache_folder=str(ROOT / ".cache/sentence-transformers"),
        model_kwargs={"use_safetensors": True},
    )
    model.float()
    model.eval()
    if model.get_embedding_dimension() != settings["dimensions"]:
        raise ValueError("Unexpected embedding dimension")
    if model.max_seq_length != config["chunking"]["max_total_input_tokens"]:
        raise ValueError("Model input limit differs from the planned tokenizer contract")
    return model, {"files_sha256": hashes, "pooling": pooling}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--download-model", action="store_true", help="Fetch pinned public model files before offline encoding")
    args = parser.parse_args()
    config = json.loads((ROOT / "config/rag-plan.json").read_text(encoding="utf-8"))
    settings = config["embeddings"]
    pilot_directory = ROOT / config["pilot"]["output_directory"]
    chunks_path = pilot_directory / "chunks.jsonl"
    pilot_manifest_path = pilot_directory / "manifest.json"
    pilot_manifest = json.loads(pilot_manifest_path.read_text(encoding="utf-8"))
    if sha_file(chunks_path) != pilot_manifest["outputs"]["chunks.jsonl"]:
        raise ValueError("Chunks changed after preparation; rebuild or review the pilot first")
    if pilot_manifest["tokenizer"]["revision"] != settings["revision"]:
        raise ValueError("Embedding revision must match the preparation tokenizer revision")
    chunks = [json.loads(line) for line in chunks_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if not chunks or len({c["chunk_id"] for c in chunks}) != len(chunks):
        raise ValueError("Expected non-empty chunks with unique IDs")
    started = time.perf_counter()
    model, model_info = load_model(config, args.download_model)
    import numpy as np

    texts = [chunk["embedding_input"] for chunk in chunks]
    lengths = []
    for chunk, text in zip(chunks, texts):
        if not text.startswith(settings["document_prefix"]):
            raise ValueError("Chunk lacks the E5 document prefix")
        ids = model.tokenizer.encode(text, add_special_tokens=True, truncation=False)
        if len(ids) != chunk["input_tokens_including_prefix_and_special_tokens"]:
            raise ValueError(f"Tokenizer count mismatch: {chunk['chunk_id']}")
        if len(ids) > model.max_seq_length:
            raise ValueError("Refusing to silently truncate an embedding input")
        lengths.append(len(ids))
    encoding_start = time.perf_counter()
    vectors = model.encode(
        texts, batch_size=settings["batch_size"], prompt="", precision=settings["precision"],
        normalize_embeddings=settings["normalize_embeddings"], convert_to_numpy=True,
        show_progress_bar=True,
    )
    encoding_seconds = time.perf_counter() - encoding_start
    expected_shape = (len(chunks), settings["dimensions"])
    if vectors.shape != expected_shape or vectors.dtype != np.float32 or not np.isfinite(vectors).all():
        raise ValueError("Invalid embedding array shape, dtype or values")
    norms = np.linalg.norm(vectors, axis=1)
    if not np.allclose(norms, 1.0, atol=1e-5):
        raise ValueError("Expected L2-normalized embeddings")
    output = ROOT / settings["output_directory"]
    output.mkdir(parents=True, exist_ok=True)
    array_path = output / "vectors.npy"
    np.save(array_path, vectors, allow_pickle=False)
    rows_path = output / "rows.jsonl"
    rows = [{"row": i, "chunk_id": c["chunk_id"], "source_id": c["source_id"],
             "section_id": c["section_id"], "input_sha256": text_hash(c["embedding_input"]),
             "input_tokens": lengths[i], "review_status": c["review_status"],
             "approved_for_production_index": c["approved_for_production_index"]} for i, c in enumerate(chunks)]
    rows_path.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows), encoding="utf-8")
    spec = {"model": settings["model"], "revision": settings["revision"],
            "dimensions": settings["dimensions"], "normalization": "L2",
            "document_prefix": settings["document_prefix"], "query_prefix": settings["query_prefix"],
            "precision": settings["precision"], "model_files_sha256": model_info["files_sha256"]}
    manifest = {
        "created_at": datetime.now(timezone.utc).isoformat(), "stage": "embeddings_only_no_vector_store",
        "embedding_spec": spec,
        "embedding_spec_sha256": text_hash(json.dumps(spec, sort_keys=True)),
        "model_info": model_info,
        "inputs": {"chunks_path": chunks_path.relative_to(ROOT).as_posix(),
                   "chunks_sha256": sha_file(chunks_path), "pilot_manifest_sha256": sha_file(pilot_manifest_path)},
        "script_sha256": sha_file(Path(__file__)), "config_sha256": sha_file(ROOT / "config/rag-plan.json"),
        "runtime": {"python": platform.python_version(), "device": str(model.device),
                    "cpu_threads": settings["cpu_threads"], "batch_size": settings["batch_size"],
                    "packages": {p: importlib.metadata.version(p) for p in
                                 ["numpy", "torch", "sentence-transformers", "transformers", "tokenizers", "huggingface-hub"]}},
        "summary": {"vectors": len(chunks), "shape": list(vectors.shape), "dtype": str(vectors.dtype),
                    "min_input_tokens": min(lengths), "max_input_tokens": max(lengths),
                    "min_l2_norm": float(norms.min()), "max_l2_norm": float(norms.max()),
                    "encoding_seconds": round(encoding_seconds, 3),
                    "total_seconds_including_load_or_download": round(time.perf_counter() - started, 3),
                    "all_values_finite": True, "all_inputs_within_limit": True,
                    "llm_calls": 0, "vector_store_created": False},
        "outputs": {"vectors.npy": {"sha256": sha_file(array_path), "bytes": array_path.stat().st_size},
                    "rows.jsonl": {"sha256": sha_file(rows_path), "bytes": rows_path.stat().st_size}},
        "usage": "Keep rows aligned with vectors. For queries use query: prefix, the same revision and normalization.",
        "limitations": ["Technical integrity checks are not retrieval quality evaluation.",
                        "Draft source review flags remain unchanged; no production approval inferred from embeddings.",
                        "Map embeddings do not calculate geographic distances or routes."],
    }
    write_json(output / "manifest.json", manifest)
    print(json.dumps({"output": str(output), "summary": manifest["summary"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
