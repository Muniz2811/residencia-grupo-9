"""Prepare five HTML documents and a KML inventory; never embed or query an LLM."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import re
import ssl
import statistics
import unicodedata
import xml.etree.ElementTree as ET
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen

from bs4 import BeautifulSoup, Tag
from tokenizers import Tokenizer


ROOT = Path(__file__).resolve().parents[1]
VERSION = "pilot-structure-v1"
DEFERRED = {
    "DOC-003": "Apoio estudantil e trechos de RU; ampliar depois do recorte de localização.",
    "DOC-004": "Atendimento de apoio; recorte atual prioriza prédios e serviços centrais.",
    "DOC-006": "Infraestrutura de laboratórios de ensino; detalhamento para uma ampliação posterior.",
    "DOC-008": "Biblioteca em portal de curso; priorizada a página específica da unidade na BCE.",
    "DOC-009": "Conteúdo principal contém somente rótulos de espaços e inclui RU; pouca descrição útil.",
    "DOC-010": "Apoio psicopedagógico; deixado para ampliação temática.",
    "DOC-011": "Grupos de pesquisa; o DOC-005 foi priorizado pelas relações explícitas prédio/andar/sala.",
    "DOC-013": "Serviço multicampus: exige seleção das orientações aplicáveis ao Gama.",
    "DOC-014": "HTML é visualizador de Word; texto da FAQ ainda não está disponível para extração.",
    "DOC-025": "Apresentação do transporte; não é uma base de itinerários e horários.",
    "DOC-026": "Orientações de consulta com resultados em iframe externo, não preservados no HTML.",
    "DOC-027": "Orientações de consulta por linha; tabelas do iframe não foram adquiridas.",
}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def norm(text: str) -> str:
    return " ".join(text.replace("\xa0", " ").split())


def folded(text: str) -> str:
    return unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode().lower()


def write_json(path: Path, data: object) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_jsonl(path: Path, data: list[dict]) -> None:
    path.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in data), encoding="utf-8")


def ensure_tokenizer(config: dict, download: bool, ca_bundle: Path | None) -> tuple[Path, dict]:
    settings = config["chunking"]
    path = ROOT / settings["tokenizer_file"]
    url = f"https://huggingface.co/{config['embeddings']['model']}/resolve/{settings['tokenizer_revision']}/tokenizer.json"
    if not path.exists():
        if not download:
            raise ValueError("Tokenizer not cached. Run once with --download-tokenizer; only the tokenizer JSON is fetched.")
        context = ssl.create_default_context(cafile=str(ca_bundle) if ca_bundle else None)
        with urlopen(Request(url, headers={"User-Agent": "UnBGamaPilot/0.1"}), timeout=90, context=context) as response:
            raw = response.read(30 * 1024 * 1024 + 1)
        if digest(raw) != settings["tokenizer_sha256"]:
            raise ValueError("Downloaded tokenizer does not match the pinned SHA-256")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
    raw = path.read_bytes()
    if digest(raw) != settings["tokenizer_sha256"]:
        raise ValueError("Cached tokenizer integrity mismatch")
    manifest = {"model": config["embeddings"]["model"], "revision": settings["tokenizer_revision"],
                "url": url, "sha256": digest(raw), "bytes": len(raw),
                "purpose": "Token counting only; no model weights or embeddings downloaded"}
    write_json(ROOT / settings["tokenizer_manifest"], manifest)
    return path, manifest


def main_content(soup: BeautifulSoup) -> Tag | None:
    return soup.select_one("main article .entry-content") or soup.select_one("main article") or soup.select_one("main")


def locator(node: Tag) -> str:
    """CSS locator in the original snapshot, before any cleanup changes."""
    parts = []
    current = node
    while isinstance(current, Tag) and current.name != "[document]":
        if current.get("id"):
            parts.append(f"#{current['id']}")
            break
        if current.get("data-id"):
            parts.append(f"[data-id='{current['data-id']}']")
            break
        position = 1 + sum(s.name == current.name for s in current.previous_siblings if isinstance(s, Tag))
        parts.append(f"{current.name}:nth-of-type({position})")
        current = current.parent
    return " > ".join(reversed(parts))


def lines(node: Tag) -> list[str]:
    clone = BeautifulSoup(str(node), "html.parser")
    for br in clone.find_all("br"):
        br.replace_with("\n")
    return [norm(line) for line in clone.get_text().splitlines() if norm(line)]


def unit(heading: str, nodes: list[Tag], text: str | None = None, **extra: object) -> dict:
    return {
        "heading": norm(heading),
        "heading_origin": "source_or_editorial_label_recorded_in_extraction_rules",
        "text": text if text is not None else "\n\n".join(norm(n.get_text(" ", strip=True)) for n in nodes),
        "html_selectors": [locator(n) for n in nodes],
        **extra,
    }


def extract_html(source_id: str, content: Tag) -> tuple[list[dict], list[str]]:
    if source_id == "DOC-001":
        return [unit("Infraestrutura — texto principal", content.find_all("p"), heading_origin="editorial_label")], [
            "Descrição não exaustiva: a ausência de LDTEA nesta página não comprova inexistência do prédio.",
            "A referência genérica a secretaria na UED deve ser distinguida da Secretaria de Graduação na UAC do DOC-002.",
        ]
    if source_id == "DOC-007":
        nodes = [n for n in content.find_all(["p", "ul"]) if norm(n.get_text(" ", strip=True))]
        return [unit("UAC — salas e recursos de ensino", nodes, heading_origin="editorial_label_from_source_text")], [
            "Quantidades e recursos são declarações da página; vigência e funcionamento atual não foram confirmados.",
            "Não inferir ocupação, funcionamento de equipamentos ou rota acessível com base na descrição.",
        ]
    if source_id == "DOC-002":
        units = []
        for item in content.select(".eael-accordion-list"):
            heading = item.select_one(".eael-accordion-tab-title")
            body = item.select_one(".eael-accordion-content")
            if heading is None or body is None:
                continue
            kept = []
            for p in body.find_all("p"):
                text = norm(p.get_text(" ", strip=True))
                if text and not folded(text).startswith(("servidor", "servidores")):
                    kept.append(p)
            if kept:
                units.append(unit(heading.get_text(" ", strip=True), kept, heading_origin="source_accordion_title"))
        return units, [
            "Pessoas e escalas individuais foram removidas; contatos institucionais do setor foram preservados.",
            "O bloco de destaque da secretaria não foi duplicado: a extração usa os doze acordeões.",
            "Horários são os publicados no snapshot; não há confirmação independente de vigência.",
        ]
    if source_id == "DOC-005":
        units = []
        for item in content.select(".eael-accordion-list"):
            category = item.select_one(".eael-accordion-tab-title")
            body = item.select_one(".eael-accordion-content")
            if category is None or body is None:
                continue
            for p in body.find_all("p"):
                if not norm(p.get_text(" ", strip=True)):
                    continue
                name = p.find(["strong", "b"])
                location = [line for line in lines(p) if re.match(r"^Local\s*:", line, re.I)]
                if name is None or not location:
                    raise ValueError("Laboratory block without explicit name and location; inspect the snapshot")
                label = norm(name.get_text(" ", strip=True))
                text = label + "\n" + "\n".join(location)
                units.append(unit(category.get_text(" ", strip=True) + " / " + label, [p], text,
                                  heading_origin="source_accordion_title_and_lab_name"))
        return units, [
            "Uma unidade por laboratório: nome e localização permanecem juntos; contatos pessoais foram removidos.",
            "Salas compartilhadas não foram tratadas como erro nem usadas para fundir laboratórios.",
            "Siglas, códigos e múltiplas localizações foram preservados; andar ausente permanece desconhecido.",
        ]
    if source_id == "DOC-012":
        # Explicit rules for this frozen snapshot, retaining the original DOM locators.
        groups = [
            ("Espaços de estudo", ["afd70b7"]),
            ("Acervo", ["27ab34a"]),
            ("Localização", ["2c6bd7c"]),
            ("Funcionamento", ["709f9aa"]),
            ("Serviços e público acadêmico", ["4d99f9c", "2a5aa8b", "efaa7f4", "df2d56c"]),
            ("Comunidade externa — acesso e condições", ["e760ecd", "9c2adb7", "e10eb59", "3861e89"]),
        ]
        units = []
        for heading, ids in groups:
            nodes = [content.select_one(f"[data-id='{identifier}']") for identifier in ids]
            if any(n is None for n in nodes):
                raise ValueError(f"Missing library block: {heading}")
            units.append(unit(heading, nodes, heading_origin="editorial_group_label"))
        return units, [
            "Rótulos de espaços, acervo e localização são editoriais; os seletores apontam aos blocos originais.",
            "Finalidade, doações, nome da responsável e listas de produções foram deixados fora deste recorte.",
            "O trecho de capacitação menciona FCE em uma página do Gama; foi excluído por ambiguidade de campus.",
            "Estatísticas de acervo e horários não têm vigência confirmada; responder como informação publicada, sem garantia de atualidade.",
            "Regras de acesso externo e restrição de empréstimo foram mantidas na mesma unidade.",
        ]
    raise ValueError(f"No pilot extraction rule for {source_id}")


def build_document(source_id: str, title: str, source_path: str, source_url: str | None,
                   sha256: str, units: list[dict], limitations: list[str], **extra: object) -> dict:
    sections = []
    text = ""
    for number, item in enumerate(units, 1):
        body = item["text"].strip()
        if not body:
            continue
        if text:
            text += "\n\n"
        # Keep labels in canonical text as well as metadata, so a future fixed-window
        # baseline sees the same titles/labels rather than being deprived of them.
        heading_start = len(text)
        text += item["heading"] + "\n"
        start = len(text)
        text += body
        sections.append({**item, "text": body, "section_id": f"{source_id}-S{number:03d}",
                         "heading_char_start": heading_start, "heading_char_end": start - 1,
                         "char_start": start, "char_end": len(text)})
    return {
        "source_id": source_id, "title": title, "campus_id": "unb_gama",
        "source_path": source_path, "source_url": source_url, "source_sha256": sha256,
        "text": text, "sections": sections, "limitations": limitations,
        "review_status": "draft_pending_human_confirmation", "approved_for_production_index": False,
        **extra,
    }


def import_map(config: dict) -> tuple[dict, dict, dict]:
    path = ROOT / config["map_file"]
    raw = path.read_bytes()
    tree = ET.fromstring(raw)
    ns = {"k": "http://www.opengis.net/kml/2.2"}
    features = []
    units = []
    generic = {folded(n) for n in config["ambiguous_map_labels"]}
    excluded = {folded(n) for n in config["exclude_map_labels"]}
    map_hash = digest(raw)
    for position, place in enumerate(tree.findall(".//k:Placemark", ns), 1):
        name = norm(place.findtext("k:name", default="", namespaces=ns))
        description = norm(place.findtext("k:description", default="", namespaces=ns))
        coordinates = place.findtext("k:Point/k:coordinates", default="", namespaces=ns).strip()
        if not coordinates:
            raise ValueError("The current pilot expects Point markers; other geometries need explicit handling")
        values = [float(v) for v in coordinates.split(",")]
        lon, lat = values[:2]
        if not (-180 <= lon <= 180 and -90 <= lat <= 90):
            raise ValueError("Invalid KML coordinates")
        flags = []
        eligible = True
        if folded(name) in excluded:
            eligible = False
            flags.append("excluded_topic_ru")
        if folded(name) in generic:
            eligible = False
            flags.append("ambiguous_label_needs_identification")
        if folded(name).startswith("entada"):
            flags.append("possible_spelling_error_original_preserved")
        canonical = "BLD-UAC" if "uac" in folded(name) or "unidade academica" in folded(name) else None
        candidate = "BLD-UED" if "docencia" in folded(name) else None
        label = folded(name)
        kind = ("parking" if "estacionamento" in label else
                "campus_access" if label.startswith("entrada") and "fcte" in label else
                "building_entry" if label.startswith(("entrada", "entada")) else
                "building_reference_point" if canonical else
                "sports_area" if "quadra" in label else
                "outdoor_area" if "praca" in label else
                "container_reference_point" if "container" in label else "other_reference_point")
        point_id = f"MAP-001-P{position:03d}"
        props = {
            "point_id": point_id, "name": name, "description": description, "kind": kind,
            "source_id": config["map_source_id"], "source_path": config["map_file"],
            "source_sha256": map_hash, "source_locator": f"/kml/Document/Placemark[{position}]",
            "location_source": "user_supplied_mymaps_annotation", "field_verified": False,
            "building_id": canonical, "candidate_building_id": candidate,
            "pilot_eligible": eligible, "quality_flags": flags,
            "original_altitude": values[2] if len(values) > 2 else None,
        }
        features.append({"type": "Feature", "id": point_id,
                         "geometry": {"type": "Point", "coordinates": [lon, lat]}, "properties": props})
        if eligible:
            text = f"Marcador informado pela equipe: {name}."
            if description:
                text += "\nDescrição informada: " + description
            text += f"\nCoordenada do marcador: latitude {lat}, longitude {lon}."
            units.append({"heading": name, "heading_origin": "kml_placemark_name", "text": text,
                          "html_selectors": [], "point_id": point_id, "building_id": canonical,
                          "source_locator": props["source_locator"]})
    duplicates = {name: count for name, count in Counter(f["properties"]["name"] for f in features).items() if count > 1}
    document = build_document(config["map_source_id"], "Mapeamento da equipe — campus Gama",
                              config["map_file"], None, map_hash, units, [
        "Pontos fornecidos pela equipe; não são contornos, rotas nem posições verificadas em campo.",
        "O KML é uma fonte; seus marcadores não contam como documentos-fonte independentes.",
        "Altitude zero não indica térreo; distâncias e rotas exigem cálculo separado dos embeddings.",
        "UED é associação candidata das entradas de docência; não há marcador explicitamente chamado LDTEA.",
        "Praça Solar não foi fundida com a coleta Praça da FCTE; o nome e a identidade precisam ser conferidos.",
    ], source_type="team_kml")
    audit = {"total_points": len(features), "pilot_eligible_points": len(units), "duplicate_labels": duplicates,
             "excluded_points": [{"point_id": f["id"], "name": f["properties"]["name"],
                                  "reasons": f["properties"]["quality_flags"]}
                                 for f in features if not f["properties"]["pilot_eligible"]]}
    return document, {"type": "FeatureCollection", "features": features}, audit


def split_section(text: str, prefix: str, tokenizer: Tokenizer, target: int, hard: int, overlap: int) -> list[tuple[int, int]]:
    def size(body: str) -> int:
        return len(tokenizer.encode(prefix + body).ids)
    if size(text) <= hard:
        return [(0, len(text))]
    spans = []
    start = 0
    while start < len(text):
        if size(text[start:]) <= target:
            end = len(text)
        else:
            lo, hi = start + 1, len(text)
            while lo < hi:
                mid = (lo + hi + 1) // 2
                if size(text[start:mid]) <= target:
                    lo = mid
                else:
                    hi = mid - 1
            end = lo
            # Prefer paragraph/sentence/word boundaries inside the available budget.
            floor = start + max(1, (end - start) // 2)
            candidates = list(re.finditer(r"\n\n|(?<=[.!?])\s+|\n|\s+", text[floor:end]))
            if candidates:
                strong = [m for m in candidates if "\n" in m.group() or text[floor + m.start() - 1:floor + m.start()] in ".!?"]
                end = floor + (strong[-1] if strong else candidates[-1]).start()
        while start < end and text[start].isspace():
            start += 1
        while end > start and text[end - 1].isspace():
            end -= 1
        if end <= start or size(text[start:end]) > hard:
            raise ValueError("Unable to split a section within the tokenizer budget")
        spans.append((start, end))
        if end >= len(text):
            break
        encoded = tokenizer.encode(text[start:end], add_special_tokens=False)
        offsets = [(a, b) for a, b in encoded.offsets if b > a]
        next_start = end
        if overlap and len(offsets) > overlap:
            proposed = start + offsets[-overlap][0]
            whitespace = re.search(r"\s+", text[proposed:end])
            if whitespace:
                next_start = proposed + whitespace.end()
        start = next_start if next_start > start else end
        while start < len(text) and text[start].isspace():
            start += 1
    return spans


def create_chunks(documents: list[dict], config: dict, tokenizer: Tokenizer) -> list[dict]:
    result = []
    for document in documents:
        for section in document["sections"]:
            prefix = f"passage: Campus: UnB Gama / FCTE\nDocumento: {document['title']}\nSeção: {section['heading']}\n"
            ranges = split_section(section["text"], prefix, tokenizer, config["target_tokens"],
                                   config["pilot_hard_total_input_tokens"],
                                   config["overlap_tokens_for_split_sections_only"])
            previous_end = 0
            for part, (start, end) in enumerate(ranges, 1):
                text = section["text"][start:end]
                embedding_input = prefix + text
                token_count = len(tokenizer.encode(embedding_input).ids)
                if token_count > config["pilot_hard_total_input_tokens"]:
                    raise ValueError("Chunk exceeds the full-input token budget")
                buildings = sorted(set(re.findall(r"\b(?:UAC|UED|LDTEA)\b", text)))
                if section.get("building_id"):
                    buildings = sorted(set(buildings + [section["building_id"].removeprefix("BLD-")]))
                chunk_hash = digest((VERSION + document["source_sha256"] + section["section_id"] + text).encode("utf-8"))
                result.append({
                    "chunk_id": f"{section['section_id']}-C{part:02d}-{chunk_hash[:10]}",
                    "source_id": document["source_id"], "section_id": section["section_id"],
                    "section": section["heading"], "text": text, "embedding_input": embedding_input,
                    "input_tokens_including_prefix_and_special_tokens": token_count,
                    "body_tokens": len(tokenizer.encode(text, add_special_tokens=False).ids),
                    "overlap_body_tokens": len(tokenizer.encode(section["text"][start:previous_end], add_special_tokens=False).ids) if start < previous_end else 0,
                    "source_span": {"char_start": section["char_start"] + start, "char_end": section["char_start"] + end,
                                    "coordinate_system": "unicode_characters_in_prepared_document_text"},
                    "source_path": document["source_path"], "source_url": document["source_url"],
                    "source_sha256": document["source_sha256"], "html_selectors": section["html_selectors"],
                    "source_locator": section.get("source_locator"), "point_id": section.get("point_id"),
                    "campus_id": "unb_gama", "building_ids": buildings,
                    "validity": "unknown; source snapshot is not a guarantee of current operation",
                    "review_status": document["review_status"], "approved_for_production_index": False,
                })
                previous_end = end
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--download-tokenizer", action="store_true", help="Fetch only the pinned tokenizer JSON if absent")
    parser.add_argument("--ca-bundle", type=Path, help="Optional trusted CA bundle; TLS verification stays enabled")
    args = parser.parse_args()
    config = json.loads((ROOT / "config/rag-plan.json").read_text(encoding="utf-8"))
    pilot = config["pilot"]
    snapshot_path = ROOT / pilot["snapshot_manifest"]
    snapshot = json.loads(snapshot_path.read_text(encoding="utf-8"))
    selected = {s["source_id"]: s["reason"] for s in pilot["html_sources"]}
    tokenizer_path, tokenizer_manifest = ensure_tokenizer(config, args.download_tokenizer, args.ca_bundle)
    tokenizer = Tokenizer.from_file(str(tokenizer_path))
    tokenizer.no_truncation()
    tokenizer.no_padding()
    documents = []
    html_audit = []
    for source in snapshot["sources"]:
        path = snapshot_path.parent / source["local_path"]
        raw = path.read_bytes()
        if digest(raw) != source["sha256"]:
            raise ValueError(f"Original HTML integrity mismatch: {source['source_id']}")
        soup = BeautifulSoup(raw, "html.parser")
        content = main_content(soup)
        sid = source["source_id"]
        html_audit.append({"source_id": sid, "title": source["audit"]["html_title"],
                           "main_text_characters": len(norm(content.get_text(" ", strip=True))) if content else 0,
                           "selected": sid in selected,
                           "selection_reason": selected.get(sid, DEFERRED.get(sid, "Conteúdo de pesquisa/LITE para ampliação posterior; o diretório de locais tem prioridade neste piloto.")),
                           "iframe_count": len(soup.find_all("iframe"))})
        if sid not in selected:
            continue
        if content is None:
            raise ValueError(f"Selected source without main content: {sid}")
        units, limitations = extract_html(sid, content)
        if not units:
            raise ValueError(f"No units extracted: {sid}")
        documents.append(build_document(sid, source["audit"]["html_title"], path.relative_to(ROOT).as_posix(),
                                        source["requested_url"], source["sha256"], units, limitations,
                                        source_type="institutional_html", downloaded_at=source["downloaded_at"]))
    map_document, places, map_audit = import_map(pilot)
    documents.append(map_document)
    chunks = create_chunks(documents, config["chunking"], tokenizer)
    output = ROOT / pilot["output_directory"]
    output.mkdir(parents=True, exist_ok=True)
    write_jsonl(output / "documents.jsonl", documents)
    write_jsonl(output / "chunks.jsonl", chunks)
    write_json(output / "places.geojson", places)
    counts = Counter(c["source_id"] for c in chunks)
    manifest = {
        "prepared_at": datetime.now(timezone.utc).isoformat(), "pipeline_version": VERSION,
        "config_sha256": digest((ROOT / "config/rag-plan.json").read_bytes()),
        "script_sha256": digest(Path(__file__).read_bytes()), "tokenizer": tokenizer_manifest,
        "packages": {name: importlib.metadata.version(name) for name in ["beautifulsoup4", "tokenizers"]},
        "html_audit": html_audit, "map_audit": map_audit,
        "summary": {"html_documents_prepared": len(documents) - 1, "map_sources": 1,
                    "sections": sum(len(d["sections"]) for d in documents), "chunks": len(chunks),
                    "chunks_per_source": dict(counts),
                    "min_input_tokens": min(c["input_tokens_including_prefix_and_special_tokens"] for c in chunks),
                    "max_input_tokens": max(c["input_tokens_including_prefix_and_special_tokens"] for c in chunks),
                    "mean_input_tokens": round(statistics.mean(c["input_tokens_including_prefix_and_special_tokens"] for c in chunks), 1),
                    "median_input_tokens": statistics.median(c["input_tokens_including_prefix_and_special_tokens"] for c in chunks),
                    "split_sections": sum(len([c for c in chunks if c["section_id"] == s["section_id"]]) > 1 for d in documents for s in d["sections"]),
                    "embeddings_generated": 0, "llm_calls": 0, "vector_store_created": False},
        "outputs": {p.name: digest(p.read_bytes()) for p in sorted(output.iterdir()) if p.name in {"documents.jsonl", "chunks.jsonl", "places.geojson"}},
        "review_status": "draft_pending_human_confirmation",
    }
    write_json(output / "manifest.json", manifest)
    print(json.dumps({"output": str(output), "summary": manifest["summary"], "map_audit": map_audit}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
