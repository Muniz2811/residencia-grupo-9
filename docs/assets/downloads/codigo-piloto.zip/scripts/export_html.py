"""Preserve HTML snapshots from the source inventory; no extraction or indexing.

Uses only the Python standard library. Each run writes to a new UTC directory.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import ssl
import sys
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from html.parser import HTMLParser
from http.cookiejar import CookieJar
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import HTTPSHandler, HTTPCookieProcessor, OpenerDirector, Request, build_opener


PROJECT_ROOT = Path(__file__).resolve().parents[1]
MAX_BYTES = 10 * 1024 * 1024
USER_AGENT = "UnBGamaKnowledgeCollector/0.1 (academic HTML snapshot collection)"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class HtmlAudit(HTMLParser):
    """Collect inspection hints, not a cleaned document for the RAG."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.title_parts: list[str] = []
        self.text_parts: list[str] = []
        self.headings: list[str] = []
        self.iframes: list[str] = []
        self.in_title = False
        self.heading_tag: str | None = None
        self.heading_parts: list[str] = []
        self.ignored_depth = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in {"script", "style", "noscript", "svg"}:
            self.ignored_depth += 1
        if self.ignored_depth:
            return
        if tag == "title":
            self.in_title = True
        if tag in {"h1", "h2", "h3"}:
            self.heading_tag = tag
            self.heading_parts = []
        if tag == "iframe":
            src = dict(attrs).get("src")
            if src:
                self.iframes.append(src)

    def handle_endtag(self, tag: str) -> None:
        if tag in {"script", "style", "noscript", "svg"}:
            self.ignored_depth = max(0, self.ignored_depth - 1)
            return
        if self.ignored_depth:
            return
        if tag == "title":
            self.in_title = False
        if tag == self.heading_tag:
            text = " ".join(" ".join(self.heading_parts).split())
            if text:
                self.headings.append(text)
            self.heading_tag = None

    def handle_data(self, data: str) -> None:
        if self.ignored_depth:
            return
        if self.in_title:
            self.title_parts.append(data)
        if self.heading_tag:
            self.heading_parts.append(data)
        if data.strip():
            self.text_parts.append(data.strip())


def inspect_html(body: bytes, declared_encoding: str | None) -> dict:
    encoding = declared_encoding
    if not encoding:
        match = re.search(rb"charset\s*=\s*[\"']?([a-zA-Z0-9_-]+)", body[:8192], re.I)
        encoding = match.group(1).decode("ascii") if match else "utf-8"
    try:
        decoded = body.decode(encoding, errors="replace")
    except LookupError:
        encoding = "utf-8"
        decoded = body.decode(encoding, errors="replace")
    audit = HtmlAudit()
    audit.feed(decoded)
    title = " ".join(" ".join(audit.title_parts).split())
    visible_text = " ".join(audit.text_parts)
    warnings = []
    if not title:
        warnings.append("missing_html_title")
    if len(visible_text) < 400:
        warnings.append("little_text_in_html_review_needed")
    if audit.iframes:
        warnings.append("iframe_content_not_downloaded")
    blocked = any(term in title.lower() for term in (
        "just a moment", "access denied", "attention required", "verify you are human",
        "403 forbidden", "404 not found", "page not found", "página não encontrada",
    ))
    return {
        "encoding_for_audit": encoding,
        "html_title": title,
        "headings_preview": audit.headings[:16],
        "text_characters_including_navigation": len(visible_text),
        "iframes": list(dict.fromkeys(audit.iframes)),
        "warnings": warnings,
        "suspected_error_or_challenge_page": blocked,
    }


def export_source(source: dict, output: Path, timeout: float, opener: OpenerDirector) -> dict:
    record = {
        "source_id": source["document_id"],
        "catalog_title": source["title"],
        "requested_url": source["url"],
        "scope": source["scope"],
        "curation_status": "pending_review",
    }
    for attempt in range(1, 4):
        record["attempts"] = attempt
        record["requested_at"] = utc_now()
        try:
            request = Request(source["url"], headers={
                "User-Agent": USER_AGENT,
                "Accept": "text/html,application/xhtml+xml;q=0.9",
                "Accept-Encoding": "identity",
            })
            with opener.open(request, timeout=timeout) as response:
                record.update({
                    "http_status": response.status,
                    "final_url": response.url,
                    "content_type": response.headers.get("Content-Type"),
                    "last_modified": response.headers.get("Last-Modified"),
                    "etag": response.headers.get("ETag"),
                })
                body = response.read(MAX_BYTES + 1)
                if len(body) > MAX_BYTES:
                    raise ValueError("Response exceeds the 10 MiB limit")
                content_type = response.headers.get_content_type()
                if content_type not in {"text/html", "application/xhtml+xml"}:
                    raise ValueError(f"Expected HTML, received {content_type}")
                audit = inspect_html(body, response.headers.get_content_charset())
                if (urlparse(response.url).hostname or "").endswith(".sharepoint.com"):
                    audit["warnings"].append("office_viewer_html_is_not_the_underlying_document_text")
                    audit["requires_document_extraction_followup"] = True
            filename = f"{source['document_id']}.html"
            # Preserve the response bytes; do not inject tags, rewrite URLs or clean HTML.
            with (output / filename).open("xb") as destination:
                destination.write(body)
            record.update({
                "downloaded_at": utc_now(),
                "local_path": filename,
                "bytes": len(body),
                "sha256": hashlib.sha256(body).hexdigest(),
                "audit": audit,
                "status": "needs_inspection" if audit["suspected_error_or_challenge_page"] else "downloaded",
            })
            return record
        except HTTPError as exc:
            record.update({"http_status": exc.code, "final_url": exc.url, "error": str(exc)})
            retry_after = exc.headers.get("Retry-After", "")
            exc.close()
            if exc.code not in {408, 429, 500, 502, 503, 504} or attempt == 3:
                break
            # Long rate limits are reported rather than repeatedly contacting the host.
            if exc.code == 429 and (not retry_after.isdigit() or int(retry_after) > 10):
                break
            time.sleep(max(attempt, int(retry_after) if retry_after.isdigit() else 0))
        except (URLError, TimeoutError, OSError) as exc:
            record["error"] = f"{type(exc).__name__}: {exc}"
            if attempt == 3:
                break
            time.sleep(attempt)
        except ValueError as exc:
            record["error"] = str(exc)
            break
    record.update({"status": "failed", "finished_at": utc_now()})
    return record


def export_host(sources: list[dict], output: Path, timeout: float, tls_context: ssl.SSLContext) -> list[dict]:
    results = []
    # Public document viewers can set anonymous sharing cookies across redirects.
    # Keep them in memory, like a normal browser; never persist cookies or sign in.
    opener = build_opener(HTTPCookieProcessor(CookieJar()), HTTPSHandler(context=tls_context))
    for position, source in enumerate(sources):
        if position:
            time.sleep(0.5)
        result = export_source(source, output, timeout, opener)
        results.append(result)
        print(f"{source['document_id']}: {result['status']} HTTP {result.get('http_status', '-')}", flush=True)
    return results


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--catalog", type=Path, default=PROJECT_ROOT / "catalog/researched-sources.csv")
    parser.add_argument("--output-root", type=Path, default=PROJECT_ROOT / "data/raw/official")
    parser.add_argument("--timeout", type=float, default=30)
    parser.add_argument("--ca-bundle", type=Path, help="Optional trusted CA bundle; certificate and hostname verification remain enabled")
    parser.add_argument("--resume-failed", type=Path, help="Snapshot directory whose failed downloads should be retried; preserve successful files")
    args = parser.parse_args()
    tls_context = ssl.create_default_context(cafile=str(args.ca_bundle) if args.ca_bundle else None)
    with args.catalog.open(encoding="utf-8-sig", newline="") as handle:
        sources = list(csv.DictReader(handle))
    if not sources:
        raise ValueError("The source catalog is empty")
    groups: dict[str, list[dict]] = defaultdict(list)
    ids = set()
    urls = set()
    for source in sources:
        if not re.fullmatch(r"DOC-\d{3}", source["document_id"]) or source["document_id"] in ids:
            raise ValueError("Invalid or repeated document ID")
        url = urlparse(source["url"])
        if url.scheme != "https" or not url.hostname or source["url"] in urls:
            raise ValueError("Expected distinct public HTTPS source URLs")
        ids.add(source["document_id"])
        urls.add(source["url"])
        groups[url.hostname].append(source)
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    catalog_hash = hashlib.sha256(args.catalog.read_bytes()).hexdigest()
    previous_failures = {}
    if args.resume_failed:
        output = args.resume_failed.resolve()
        manifest_bytes = (output / "manifest.json").read_bytes()
        manifest = json.loads(manifest_bytes)
        if manifest["catalog_sha256"] != catalog_hash:
            raise ValueError("The inventory changed; create a new snapshot instead of resuming")
        for record in manifest["sources"]:
            if record["status"] == "failed":
                previous_failures[record["source_id"]] = record
            elif hashlib.sha256((output / record["local_path"]).read_bytes()).hexdigest() != record["sha256"]:
                raise ValueError(f"Snapshot integrity mismatch: {record['source_id']}")
        if not previous_failures:
            print("No failed downloads to resume; snapshot left unchanged.")
            return 0
        (output / f"manifest.before-retry-{run_id}.json").write_bytes(manifest_bytes)
        manifest["sources"] = [r for r in manifest["sources"] if r["source_id"] not in previous_failures]
        manifest.setdefault("resumed_at", []).append(utc_now())
        groups = defaultdict(list)
        for source in sources:
            if source["document_id"] in previous_failures:
                groups[urlparse(source["url"]).hostname].append(source)
    else:
        output = args.output_root / run_id
        output.mkdir(parents=True, exist_ok=False)
        manifest = {
            "run_id": run_id,
            "started_at": utc_now(),
            "catalog_path": str(args.catalog.resolve()),
            "catalog_sha256": catalog_hash,
            "user_agent": USER_AGENT,
            "scope": "HTML response snapshots only; no assets, iframe contents, curation, chunks or embeddings",
            "sources": [],
        }
    manifest["tls_ca_bundle"] = str(args.ca_bundle.resolve()) if args.ca_bundle else "system_default"
    # One request at a time per host, with independent hosts processed concurrently.
    with ThreadPoolExecutor(max_workers=min(4, len(groups))) as executor:
        futures = [executor.submit(export_host, group, output, args.timeout, tls_context) for group in groups.values()]
        for future in as_completed(futures):
            for record in future.result():
                if record["source_id"] in previous_failures:
                    record["previous_failed_attempt"] = previous_failures[record["source_id"]]
                manifest["sources"].append(record)
    manifest["sources"].sort(key=lambda item: item["source_id"])
    manifest["finished_at"] = utc_now()
    manifest["counts"] = {
        "requested": len(sources),
        "downloaded": sum(item["status"] == "downloaded" for item in manifest["sources"]),
        "needs_inspection": sum(item["status"] == "needs_inspection" for item in manifest["sources"]),
        "failed": sum(item["status"] == "failed" for item in manifest["sources"]),
    }
    (output / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(output.resolve()), "counts": manifest["counts"]}, ensure_ascii=True), flush=True)
    return int(manifest["counts"]["failed"] > 0 or manifest["counts"]["needs_inspection"] > 0)


if __name__ == "__main__":
    sys.exit(main())
